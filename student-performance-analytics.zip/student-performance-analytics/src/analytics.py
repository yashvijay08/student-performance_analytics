from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = [
    "student_id", "name", "class", "maths", "science", "english", "attendance"
]
SUBJECT_COLUMNS = ["maths", "science", "english"]


def load_student_data(csv_path: str | Path) -> pd.DataFrame:
    """Load and validate student records from a CSV file."""
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    df = pd.read_csv(path)
    missing = [column for column in REQUIRED_COLUMNS if column not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")

    df = df[REQUIRED_COLUMNS].copy()
    if df.empty:
        raise ValueError("The dataset contains no student records.")

    for column in SUBJECT_COLUMNS + ["attendance"]:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    if df[SUBJECT_COLUMNS + ["attendance"]].isna().any().any():
        raise ValueError("Marks and attendance must contain valid numbers.")
    if ((df[SUBJECT_COLUMNS] < 0) | (df[SUBJECT_COLUMNS] > 100)).any().any():
        raise ValueError("Subject marks must be between 0 and 100.")
    if ((df["attendance"] < 0) | (df["attendance"] > 100)).any():
        raise ValueError("Attendance must be between 0 and 100.")

    df["student_id"] = df["student_id"].astype(str)
    df["name"] = df["name"].astype(str)
    df["class"] = df["class"].astype(str)
    return df


def calculate_student_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of the dataset with total, percentage, and grade columns."""
    result = df.copy()
    result["total"] = result[SUBJECT_COLUMNS].sum(axis=1)
    result["percentage"] = result["total"] / len(SUBJECT_COLUMNS)
    result["grade"] = result["percentage"].apply(assign_grade)
    return result


def assign_grade(percentage: float) -> str:
    """Assign a simple grade using percentage bands."""
    if percentage >= 90:
        return "A"
    if percentage >= 80:
        return "B"
    if percentage >= 70:
        return "C"
    if percentage >= 60:
        return "D"
    return "F"


def get_subject_averages(df: pd.DataFrame) -> pd.Series:
    """Calculate average marks for each subject."""
    return df[SUBJECT_COLUMNS].mean().rename(
        {"maths": "Maths", "science": "Science", "english": "English"}
    )
